import streamlit as st
import subprocess
import os

def vote_submit():
    st.title("Thank You For Voting With Us!")
    
    st.write("🎉 Congratulations! Your Vote has been successfully submitted! 🎉")
    
    st.image("/Users/da_mac_41_/Downloads/thanks.png",caption="", width=200)
    
    Home = st.button("Home")
    if Home:
        st.write('Redirecting to Home page...')
        subprocess.Popen(['streamlit', 'run', 'HomePage.py'])
    
    
vote_submit()